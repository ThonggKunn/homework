package F01_homework.homework_8.homework1;

import F01_homework.homework_8.homework1.Officer;

public class Officer_Manage extends Officer {
    Officer_Manage(String Name, int Age, String Gender, String Address) {
        super(Name, Age, Gender, Address);
    }
}
